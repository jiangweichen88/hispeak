const img = `data:image/jpeg;base64,iVBORw0KGgoAAAANSUhEUgAAABEAAAARCAYAAAA7bUf6AAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsIAAA7CARUoSoAAAAL5SURBVDhPpZJLaFNpFMd/NzeP3psmaaNJ29FqG2p9dJGqjLrw1VCxFBdCp64UNyKKIC4E0YU7waU6iouBKYgjM4IbZRxnUXXjqz7wAVaZGWtpLSa1bbQtSW7uw3PTavG1kDlZ3Jv7nfM75/v/j+JI8D/jm5CLf/fy17V/6esfo2AYVM/WaW9dxLbOZdMZM/EF5NSZe1zufkmsKkJtbYxQuAzLtBnLTnD3znOePHrJ2dNbaEstnK74DNKx8wKVsyppXtZIOKLj2DbusS1nlmVjmhbpoQwnjl3i8P4W9u1cXar7CNlz6ArRmh9oaJyHKeMbUuD1KqgepZTogjyKSqFo8HrgNSd/vsyf57axavl8PG5C7z9pTF+Y+fXVGPm8AIo01WtM5h0smaZgOjKFje2YBHx+qmritLcn2br7vFs+Bel5MkoiEUdVFCYLFrs217C2uYKVTTo5A6IhH3NiZeQF6jgWwaBORUUEPaxx/+HAFOTqrUFCwQCOQGzLQVFKn6mv1kQL6SR/I0GVuVUBLMM9h2BIo3ZOlOs3XuD5r28YmRhV9eBKWBZQufYgW4I87c+JuJAZMRjOmoR1BUuyTNukvFzH5/cxMJTF48r6NjuOIwIq8q75PTx4NslAOk9qaYRFddJdCrUA3H2Wwy/NzKItgoNRMIlENDwNiRivBt9gFd1UGVV+FSEvf3SPMjRSoH1VlL0dNaXnlpZKJkwYfytNZep05h1rVtZNabL9pyZu336KLxDAVEQEFSpDKr9dGeHe83HJmLI5GvaRHZGrKiYT7wpk0qO0rmuc2ZNURxcr1iRZ0lQv4xbFhdISic3IvljUxRVxcQytzKFcD3L8+EVOHWn7FOJa92PbL7KtDSSbEyUH3A21ZGcsccy9rN/nFeEDdHV109mW4MDelFs6A/kQnTt+p29wnGRyHrF4BE33o3pVcrkib4Yn6JFrHz3YwsbU4umKr0DcuNnTz8lfe3jcmxGAl3hMZ1PrApY0RNmwvnE6aya+Cvm+gPeAtk4ShyqjTgAAAABJRU5ErkJggg==`
// inject injected script
var s = document.createElement('script')
s.src = chrome.runtime.getURL('injected.js')
;(document.head || document.documentElement).appendChild(s)
// receive message from injected script
var isRenderCellDom = false
// 监听登录信息
// window.addEventListener('message', function(event) {
//   var data = event.data;
//   localStorage.setItem('myData', data);
// });
// chrome.runtime.sendMessage({ method: 'getLocalStorage', pageUrl: window.location.href, data: localStorage.getItem('_uetsid') })
window.addEventListener('message', function(e) {
  // console.log('content script received:', e)
  let type = e.data.type,
    data = e.data.data
  if (data) {
    try {
      const a = JSON.parse(data)
      data = a
    } catch (error) {
      // data = null
    }
  }
  if (type === 'xhr') {
    // xhr
    // console.log(data, 'xhr')
    if (data && data._url && data._url.indexOf('/api/graphql/crm') > -1 && data.__raven_xhr.status_code === 200) {
      // console.log(data, 'response222')
      // if (isRenderCellDom) return
      setTimeout(() => {
        const $dom2 = $("td[data-table-external-id*='cell-0-1-phone'] span")
        renderCellDom($dom2)
      }, 0)
    } else if (data && data._url && data._url.indexOf('/api/calls/v1/callees/omnibus/') > -1 && data.__raven_xhr.status_code === 200) {
      const $dom = $("textarea[data-selenium-test='property-input-phone']")
      // const $dom3 = $("textarea[data-unit-test='property-input-phone-button']")
      renderDom($dom)
    }
  }
})
function checkDomIsRender($dom, callback) {
  if ($dom.length) {
    callback && callback()
    return true
  } else {
    setTimeout(() => {
      console.log('hispeak_googlePlugin图标渲染中')
      checkDomIsRender($dom, callback)
    }, 100)
  }
}
function renderDom($dom) {
  if ($dom.length) {
    console.log('hispeak_googlePlugin图标渲染完成')
    if ($dom.val() && $dom.val().length > 0 && $dom.parent().find('#hispeak_googlePlugin_click').length === 0) {
      $dom.after(
        // '<a style="cursor:pointer;position: relative;top: 1px;" title="Hispeak"><img style="width: 17px;" id="hispeak_googlePlugin_click" src="https://dev.arccocc.com/adminfile/wqctest/3f6ad234fed336860fcc892524334a0.jpg"></a>'
        '<a style="cursor:pointer;position: relative;top: 1px;" title="Hispeak"><img style="width: 17px;" id="hispeak_googlePlugin_click" src=' + img + '></a>'
      )
      $dom
        .parent()
        .find('#hispeak_googlePlugin_click')
        .click(function(even) {
          even.stopPropagation()
          let data = { type: 'hispeak_googlePlugin_click', isCreate: true }
          if ($dom.val()) {
            data.phoneNumber = $dom.val().replaceAll(' ', '')
          }
          // console.log('hispeak_googlePlugin_click', data, $dom)
          send_message(data)
        })
    }
  }
}
function renderCellDom($dom) {
  if ($dom.length) {
    $('.hispeak_googlePlugin_click').off('click', fn)
    // $('.hispeak_googlePlugin_click').remove()
    console.log('hispeak_googlePlugin图标渲染完成')
    $.each($dom, function(index, item) {
      if (
        $(this)
          .parent()
          .find('.hispeak_googlePlugin_click').length > 0
      ) {
        return
      }
      if ($(this).text() && $(this).text() != '--') {
        $(this).before(
          // '<a style="cursor:pointer;position: relative;top: 1px;" title="Hispeak"><img style="width: 17px;" id="hispeak_googlePlugin_click" src="https://dev.arccocc.com/adminfile/wqctest/3f6ad234fed336860fcc892524334a0.jpg"></a>'
          '<a  class="hispeak_googlePlugin_click_a" style="cursor:pointer;position: relative;top: 4px;    margin-right: 4px;" title="Hispeak"><img style="width: 17px;" class="hispeak_googlePlugin_click" src=' +
            img +
            '></a>'
        )
        $(this)
          .parent()
          .find('.hispeak_googlePlugin_click')
          .on('click', fn)
        const _this = $(this)
        const $tr = $(_this).closest('tr')
        $tr.find('.hispeak_googlePlugin_click').on('DOMNodeRemovedFromDocument', (e) => {
          // console.log(e)
          setTimeout(() => {
            const $dom2 = $("td[data-table-external-id*='cell-0-1-phone'] span")
            renderCellDom($dom2)
            const $td = $tr.find("td[data-table-external-id*='cell-0-1-phone']")
            // console.log($td)
            const $textarea = $td.find('textarea[data-unit-test="property-input-phone-button"]')
            if ($textarea.length && $tr.find('.hispeak_googlePlugin_click').length === 0) {
              $textarea.before(
                '<a  class="hispeak_googlePlugin_click_a" style="cursor:pointer;position: relative;top: 2px;    margin-right: 4px;left: -2px;" title="Hispeak"><img style="width: 17px;" class="hispeak_googlePlugin_click" src=' +
                  img +
                  '></a>'
              )
              $tr.find('.hispeak_googlePlugin_click').on('click', (e) => {
                e.stopPropagation()
                // console.log('hispeak_googlePlugin_click', e, $(this))
                const span = $td.find('textarea')
                // console.log(span.text())
                const val = span.val()
                let data = { type: 'hispeak_googlePlugin_click', isCreate: true }
                if (val) {
                  data.phoneNumber = val.replaceAll(' ', '')
                }
                send_message(data)
              })
              $tr.find('.hispeak_googlePlugin_click').on('DOMNodeRemovedFromDocument', (e) => {
                // console.log(e)
                setTimeout(() => {
                  const $td2 = $tr.find("td[data-table-external-id*='cell-0-1-phone']")
                  $td2.find('span').each(function() {
                    if ($(this).text() && $(this).text() != '--' && $tr.find('.hispeak_googlePlugin_click').length === 0) {
                      $(this).before(
                        // '<a style="cursor:pointer;position: relative;top: 1px;" title="Hispeak"><img style="width: 17px;" id="hispeak_googlePlugin_click" src="https://dev.arccocc.com/adminfile/wqctest/3f6ad234fed336860fcc892524334a0.jpg"></a>'
                        '<a  class="hispeak_googlePlugin_click_a" style="cursor:pointer;position: relative;top: 4px;    margin-right: 4px;" title="Hispeak"><img style="width: 17px;" class="hispeak_googlePlugin_click" src=' +
                          img +
                          '></a>'
                      )
                      $(this)
                        .parent()
                        .find('.hispeak_googlePlugin_click')
                        .on('click', fn)
                    }
                  })
                }, 100)
              })
            } else {
              // console.log(1)
            }
          }, 100)
        })
      }
    })
    isRenderCellDom = true
    function fn(e) {
      // console.log(e)
      e.stopPropagation()
      // console.log('hispeak_googlePlugin_click', e, $(this))
      const span = $(this)
        .parent()
        .parent()
        .find('span')
      // console.log(span.text())
      const val = span.text()
      let data = { type: 'hispeak_googlePlugin_click', isCreate: true }
      if (val) {
        data.phoneNumber = val.replaceAll(' ', '')
      }
      send_message(data)
    }
  }
}
function send_message(data) {
  var param = { type: 'message', data: data }
  chrome.runtime.sendMessage(param)
  // function(response) {
  //   console.log('send_message log:' + response)
  // }
}

//监听dom节点变化的函数
var MutationObserver = window.MutationObserver || window.WebKitMutationObserver || window.MozMutationObserver
function observeDom($dom) {
  // 选择目标节点
  var target = $dom
  // 创建观察者对象
  var observer = new MutationObserver(function(mutations) {
    mutations.forEach(function(mutation) {
      console.log(mutation.type, 'mutation')
    })
  })
  // 配置观察选项:
  // var config = { attributes: true, childList: true, characterData: true }
  var config = {
    attributes: true,
    childList: true,
    subtree: true,
    attributeOldValue: true,
    attributeFilter: ['style']
  }
  // 传入目标节点和观察选项
  observer.observe(target, config)
  // 随后,你还可以停止观察
  // observer.disconnect();
}
console.log('查看脚本是否注入成功')
