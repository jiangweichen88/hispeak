let popupWindowId = null
var popup = null
var _popup = chrome.extension.getViews({ type: 'popup' })[0]
chrome.browserAction.onClicked.addListener((tab) => {
  // console.log(window, 'window')
  if (!popupWindowId) {
    createPopupWindow()
  } else {
    updatePopupWindow()
  }
})

chrome.windows.onRemoved.addListener((windowId) => {
  if (windowId === popupWindowId) {
    console.log('onRemoved', null)
    popupWindowId = null
  }
})
// message listener ======================================================
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  // console.log('data:' + JSON.stringify(request.data));
  if (request.type == 'message') {
    const data = request.data
    console.log(data, 'data999')
    // do something...
    // sendResponse('bg got it...');
    window.localStorage.setItem('hubspotContact', JSON.stringify(data))
    if (data.isCreate) {
      createOrUpdatePopupWindow('isCreate')
      // updatePopupWindow(() => {
      //   window.location.reload()
      // })
    } else {
      createOrUpdatePopupWindow()
    }
    // popup.GetMessageFromBackground(data)
  }
  // 等待 sendResponse 把数据返回
  return true
})

//新建或更新窗口
function createOrUpdatePopupWindow(cb) {
  if (popupWindowId) {
    if (cb) {
      window.GetMessageFromBackground({ name: 'updatePopupWindow' })
    }
    updatePopupWindow(cb)
  } else {
    createPopupWindow()
  }
}
//新建窗口
function createPopupWindow() {
  // window.GetMessageFromBackground && window.GetMessageFromBackground({ name: 'createWindow' })
  chrome.windows.create(
    {
      // url: chrome.runtime.getURL(`index.html?currentTabId=${tab.id}`),
      url: chrome.runtime.getURL(`index.html?pluginType=googlePlugin`),
      type: 'popup',
      width: 376,
      height: 650 + 30
    },
    (window) => {
      popupWindowId = window.id
      popup = chrome.extension.getViews({ type: 'popup' })[0]
      console.log(chrome.extension.getViews({ type: 'popup' }))
    }
  )
}
function updatePopupWindow(cb) {
  const _window = window
  if (popupWindowId) {
    chrome.windows.update(popupWindowId, { focused: true }, (window) => {
      popup = chrome.extension.getViews({ type: 'popup' })[0]
      // popupWindowId = window.id
      // cb && cb()
    })
  }
}
chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.method === 'getLocalStorage') {
    console.log(request)
    // chrome.runtime.sendMessage({ method: 'getLocalStorageResponse', value: localStorageValue })
  }
})
