// 获取background页面
var bg = chrome.extension && chrome.extension.getBackgroundPage()
// // 获取当前选项卡ID
// function getCurrentTabId(callback) {
//   chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
//     if (callback) callback(tabs.length ? tabs[0].id : null)
//   })
// }
if (window.$nouiInstance) {
  window.$nouiInstance.getStatus((data) => {
    const type = data.name
    const body = data.body
    if (window.$nouiInstance.getIsOutbound(body) === 0) {
      // alert('呼入振铃')
      bg && bg.updatePopupWindow()
    }
  })
}
if (window.hispeakVue && window.hispeakVue.$eventBus) {
  window.hispeakVue.$eventBus.$on('getTarget', (target) => {
    console.log(target)
    // chrome.passwords.store(target, (result) => {
    //   console.log(result)
    // })
  })
}

// message listener ======================================================
// chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
//   // console.log('data:' + JSON.stringify(request.data));
//   if (request.type == 'message') {
//     const data = request.data
//   }
//   return true
// })
if (bg) {
  bg.GetMessageFromBackground = GetMessageFromBackground
}
function GetMessageFromBackground(data) {
  console.log(data, 'GetMessageFromBackground')
  if (data.name === 'updatePopupWindow') {
    // window.location.reload()
    window.hispeakVue &&
      window.hispeakVue.$router.push({
        path: '/index',
        query: {
          t: Date.now()
        }
      })
  }
}
