window.HispeakConfig = {
  wsUrl: 'wss://aicc.arccocc.com/nws',
  baseUrl: 'https://aicc.arccocc.com'
  // wsUrl: ''
  // baseUrl: ''
}
